import bpy
from datetime import datetime
import os
import json
import threading
import subprocess
import signal

def run_server():
    subprocess.run('npm run start', shell=True)
    
th = threading.Thread()
th.daemon = True
th.run = run_server

def export_gltf(apply_modifiers, path):
    try:
        bpy.ops.object.select_all(action='SELECT')
        scene = bpy.context.scene

        abs_path = bpy.path.abspath(path)
        folder_path = os.path.join(abs_path, 'viewer/public')
        
        if not os.path.exists(folder_path):
            os.makedirs(folder_path, exist_ok=True)
        
        glb_file_path = os.path.join(folder_path, 'scene.glb')
        
        bpy.ops.export_scene.gltf(
            filepath=glb_file_path, 
            export_format='GLB', 
            use_selection=True, 
            export_apply=apply_modifiers, 
            export_lights=True, 
            export_cameras=True
        )
        
        print(f"Scene exported to: {glb_file_path}")
        
        original_cwd = os.getcwd()
        os.chdir(folder_path)
        
        glb_path = 'scene.glb'
        
        try:
            subprocess.run('node ../../gltfjsx/cli.js ' + glb_path + ' --shadows --keepnames --instance', shell=True, check=True)
            print("GLTFJSX processing completed successfully")
            
            generated_scene_js = os.path.join(folder_path, 'Scene.js')
            target_scene_js = os.path.join(abs_path, 'viewer/src/Scene.js')
            
            if os.path.exists(generated_scene_js):
                import shutil
                shutil.move(generated_scene_js, target_scene_js)
                print(f"Scene.js moved to: {target_scene_js}")
            else:
                print("Warning: Scene.js not found in public folder")
                
        except subprocess.CalledProcessError as e:
            print(f"Error running gltfjsx: {e}")
        finally:
            # Restore original working directory
            os.chdir(original_cwd)
            
    except Exception as e:
        print(f"Export failed: {e}")
        return False
    
    return True


bl_info = {
    "name": "BlenderWebViewer",
    "description": "Web Viewer for Blender",
    "author": "elia",
    "version": (0, 1, 0),
    "blender": (2, 80, 0),
    "location": "3D View > Tools",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Development"
}
import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    FloatProperty,
    FloatVectorProperty,
    EnumProperty,
    PointerProperty,
    CollectionProperty,
)
from bpy.types import (
    Panel,
    Menu,
    Operator,
    PropertyGroup,
)


# ------------------------------------------------------------------------
#    Scene Properties
# ------------------------------------------------------------------------

class MyProperties(PropertyGroup):
    
    global current_group

    apply_transform: BoolProperty(
        name="Apply Transform",
        description="",
        default = True
        )
    apply_modifiers: BoolProperty(
        name="Apply Modifiers",
        description="",
        default = True
        )
    path: StringProperty(
        name="Export Path",
        description="Directory where the scene will be exported",
        default = "//",
        subtype = 'DIR_PATH'
        )
# ------------------------------------------------------------------------
#    Operators
# ------------------------------------------------------------------------

class WM_OT_ExportScene(Operator):
    bl_label = "EXPORT"
    bl_idname = "wm.export_scene"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        
        apply_modifiers = mytool.apply_modifiers
        path = mytool.path
        
        if not path or path == "//":
            self.report({'ERROR'}, "Please set a valid export path")
            return {'CANCELLED'}
        
        success = export_gltf(apply_modifiers, path)
        
        if success:
            self.report({'INFO'}, "Scene exported successfully!")
        else:
            self.report({'ERROR'}, "Export failed - check console for details")

        return {'FINISHED'}
    

# ------------------------------------------------------------------------
#    Menus
# ------------------------------------------------------------------------

class OBJECT_MT_CustomMenu(bpy.types.Menu):
    bl_label = "Select"
    bl_idname = "OBJECT_MT_custom_menu"

    def draw(self, context):
        layout = self.layout

        # Built-in operators
        layout.operator("object.select_all", text="Select/Deselect All").action = 'TOGGLE'
        layout.operator("object.select_all", text="Inverse").action = 'INVERT'
        layout.operator("object.select_random", text="Random")

# ------------------------------------------------------------------------
#    Panels
# ------------------------------------------------------------------------

class ExportScenePanel:
    bl_space_type = "VIEW_3D"
    bl_label = "BlenderWeb"
    bl_category = "BlenderWeb"
    bl_context = "objectmode"  
    bl_region_type = "UI"

class OBJECT_PT_CustomPanel(ExportScenePanel, Panel):
    bl_idname = "OBJECT_PT_custom_panel"
    bl_label = "Main"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        global th

        layout.label(text="Path:")
        layout.prop(mytool, "path")
        layout.separator()
        layout.prop(mytool, "apply_modifiers")
        layout.separator()
        layout.operator("wm.export_scene")

# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = (
    MyProperties,
    WM_OT_ExportScene,
    OBJECT_MT_CustomMenu,
    OBJECT_PT_CustomPanel,
)
def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    bpy.types.Scene.my_tool = PointerProperty(type=MyProperties)

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.my_tool

if __name__ == "__main__":
    register()